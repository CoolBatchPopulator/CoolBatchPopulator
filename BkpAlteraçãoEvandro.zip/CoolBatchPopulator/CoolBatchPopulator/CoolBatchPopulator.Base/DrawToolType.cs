﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoolBatchPopulator
{
    #region - Enumerations -

    public enum DrawToolType
    {
        Pointer,
        File,
        Database,
        Process,
        Connector,
        NumberOfTools
    };

    #endregion

}
